<?php
defined('BASEPATH') OR exit('No direct script acces allowed');
class Test extends CI_Controller {
	



public function index()
{
	$this->load->view('Welcome_message');
}
public function cv(){
$this->load->view('cv.php');
}
}